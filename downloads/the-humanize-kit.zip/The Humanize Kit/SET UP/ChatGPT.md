# Set up in ChatGPT

ChatGPT supports skills on **Team and Enterprise** plans. That's where this kit runs in ChatGPT: the same two skills, working together, the same as in Claude.

Like the Claude app, ChatGPT can't add a skill to your settings from inside a chat, so the permanent step is a quick one you do yourself. The scoring script comes inside the kit and runs in ChatGPT's own sandbox, so there's nothing to install on your computer.

## For your AI assistant

The user wants the Humanize Kit in ChatGPT. If they're on a plan with the Skills feature (Team or Enterprise):
1. Point them to upload the two skill folders, `humanize/` and `voice-fingerprint/`, under ChatGPT's Skills feature. They sit at the zip root or inside a wrapper folder called `The Humanize Kit/`. Ignore `__MACOSX/` and `.DS_Store`.
2. You can also load both into this chat right now: read `humanize/SKILL.md` and `voice-fingerprint/SKILL.md` and hold those rules for this conversation.
3. When the user pastes a draft, follow the humanize skill: rewrite it in their voice, with the meaning locked, no em-dashes, no contrast-flip rhythm. For the score, run `humanize/scripts/ai_tells_lint.py` with Code Interpreter, before and after.
4. Walk them through the Get started steps below.

## Set it up permanently

1. Open ChatGPT's **Skills** settings (Team and Enterprise plans have this).
2. Upload the kit (this zip), or the two skill folders `humanize/` and `voice-fingerprint/`.
3. Start a new chat, paste a draft, and ask it to humanise the writing and give you the score.

Both skills load, so you get the same thing you'd get in Claude: capture your voice, then humanise with it, with the score.

## On a personal or Plus account

ChatGPT doesn't have the Skills feature on personal or Plus plans yet. So for now the kit's home is **Claude Code, Codex, or the Claude app**, where the skills run properly. If you're on ChatGPT and want a route that fits your setup, reply to your purchase email and I'll help you work one out.

## The score and paid plans

The rewrite works on any plan. The score runs a small Python script, so it needs Code Interpreter, which is a paid feature. For the full experience, including the score, use a paid plan.

## Get started

1. **Capture your voice.** Give it a few real samples of your writing and ask it to build your voice with the voice-fingerprint skill. Keep the file it makes. A few minutes, once.
2. **Humanise a draft.** Paste your text and say "humanise this in my voice and give me the before and after score."
3. Run anything through it before you publish it.
