# Set up in Claude Code

Claude Code is where I built this, and where it runs best. Setup takes a minute.

The easiest way: tell Claude Code **"set up the Humanize Kit"** and point it at this kit. It does the steps below for you. If you would rather do it by hand, skip to "Doing it by hand".

## For your AI assistant

The user wants the Humanize Kit installed in Claude Code. Do this:

1. Find the two skill folders in the unzipped kit: `humanize/` and `voice-fingerprint/`. They may sit at the zip root or inside a wrapper folder called `The Humanize Kit/`. Use the folders that contain `humanize/SKILL.md` and `voice-fingerprint/SKILL.md`. Ignore `__MACOSX/`, `.DS_Store`, and Apple resource-fork files.
2. Copy both folders into the user's personal skills directory, `~/.claude/skills/`. You should end up with `~/.claude/skills/humanize/` and `~/.claude/skills/voice-fingerprint/`. Create `~/.claude/skills/` if it isn't there.
3. If either folder already exists, ask before overwriting. Otherwise install both without asking.
4. Confirm the key files landed: `~/.claude/skills/humanize/SKILL.md`, `~/.claude/skills/voice-fingerprint/SKILL.md`, and the lint script at `~/.claude/skills/humanize/scripts/ai_tells_lint.py`.
5. Tell the user setup is done and to restart Claude Code so it loads the skills. Then walk them through the Get started steps below.

## Doing it by hand

A skill is just a folder you drop into your skills folder.

- **On a Mac:** the folder is `~/.claude/skills/`. The `.claude` part is hidden, so in Finder press **Cmd + Shift + G** and type `~/.claude` to open it. Put both folders inside `skills`, so you have `~/.claude/skills/humanize/` and `~/.claude/skills/voice-fingerprint/`.
- **On Windows:** the folder is `C:\Users\YourName\.claude\skills\` (swap in your username). If File Explorer hides `.claude`, open the **View** menu and turn on **Hidden items**.

Restart Claude Code after, and it finds the skills on its own.

## Get started

1. **Capture your voice.** Tell Claude "use the voice-fingerprint skill" and point it at a few real samples of your writing. The more it's actually you, the better. It builds a short file that captures how you write. A few minutes, and you only do it once.
2. **Humanise a draft.** Paste something you wrote, or that AI helped you write, and say "humanise this and give me the score." It finds the AI patterns, rewrites them in your voice, and shows you the before and after score.
3. That's the loop. Run anything through it before it goes out.

The score runs a small Python script. On a Mac it's almost always already there. If it isn't, ask Claude to set it up with you and it'll tell you exactly what to type. Even without it the rewrite still works, you just lose the automatic score.
