# Set up in the Claude app

No terminal, nothing to install on your computer. The Claude app runs the whole thing, and I've tested it end to end. If you also have Claude Code or Codex, those are a bit smoother, but the app does everything.

One thing worth knowing. In Claude Code the kit installs itself onto your computer. The Claude app can't add a skill to your settings for you, so that one step is yours to do, and it takes seconds. Everything else, both skills and the scoring script, comes inside the kit and runs in the app's own sandbox.

There are two ways: a quick one for right now, and a permanent one so it's always there.

## Quick start (this chat)

If you've just uploaded the kit here and want to use it now. This sets it up for this one chat; to have it in every new chat, do the permanent step further down.

### For your AI assistant
The user has uploaded the Humanize Kit in the Claude app. You can't install it to disk here, so load it into this chat instead:
1. Read both `humanize/SKILL.md` and `voice-fingerprint/SKILL.md`, plus `humanize/references/tells-catalogue.md`, and hold those rules for this conversation.
2. When the user pastes a draft, follow the humanize skill: rewrite it in their voice with the meaning locked, no em-dashes, no contrast-flip rhythm.
3. For the score, run `humanize/scripts/ai_tells_lint.py` on the draft with the analysis tool, before and after.
4. Walk the user through the Get started steps below.

## Set it up permanently

So you don't have to upload it every time:

1. In the Claude app, open **Settings (or Customise) → Skills** and upload the kit (this zip file).
2. Start a new chat, paste a draft, and ask it to humanise the writing and give you the score.

It loads the skill, runs the script for the score, and gives you the same before and after report every time.

## The score and paid plans

The rewrite works on any plan. The score runs a small Python script, so it needs the code/analysis tool switched on, which is a paid Claude feature. For the full experience, including the score, use a paid Claude plan.

## Get started

1. **Capture your voice.** Give it a few real samples of your writing and ask it to build your voice from the voice-fingerprint skill. Keep the file it makes. A few minutes, once.
2. **Humanise a draft.** Paste your text and say "humanise this in my voice and give me the before and after score."
3. Run anything through it before you send it.
