# Set up in Codex

Setup takes a minute. The kit installs the same way it does in Claude Code, just into the Codex skills folder.

The easiest way: tell Codex **"set up the Humanize Kit"** and point it at this kit. It does the steps below for you.

## For your AI assistant

The user wants the Humanize Kit installed in Codex. Do this:

1. Find the two skill folders in the unzipped kit: `humanize/` and `voice-fingerprint/`. They may sit at the zip root or inside a wrapper folder called `The Humanize Kit/`. Use the folders that contain `humanize/SKILL.md` and `voice-fingerprint/SKILL.md`. Ignore `__MACOSX/`, `.DS_Store`, and Apple resource-fork files.
2. Copy both folders into the user's Codex skills directory, `~/.codex/skills/`. You should end up with `~/.codex/skills/humanize/` and `~/.codex/skills/voice-fingerprint/`. Create `~/.codex/skills/` if it isn't there.
3. If either folder already exists, ask before overwriting. Otherwise install both without asking.
4. Confirm the key files landed: `~/.codex/skills/humanize/SKILL.md`, `~/.codex/skills/voice-fingerprint/SKILL.md`, and the lint script at `~/.codex/skills/humanize/scripts/ai_tells_lint.py`.
5. Tell the user to restart Codex so it loads the skills, then walk them through the Get started steps below.

**Path note:** the SKILL.md text gives the lint path as `~/.claude/...`. In Codex, use the `~/.codex/...` path instead:

```bash
python3 ~/.codex/skills/humanize/scripts/ai_tells_lint.py <path-to-draft>
```

## Doing it by hand

A skill is just a folder. Drop both folders into `~/.codex/skills/`, so you have `~/.codex/skills/humanize/` and `~/.codex/skills/voice-fingerprint/`. Restart Codex after.

## Get started

1. **Capture your voice.** Tell Codex "follow the voice-fingerprint skill" and point it at a few real samples of your writing. It builds a short file that captures how you write. A few minutes, and you only do it once.
2. **Humanise a draft.** Paste your text and say "follow the humanize skill, rewrite this in my voice, and run the lint script for the before and after score."
3. Run anything through it before it goes out.

In Codex you usually need to point it at the skill by name. It doesn't always pick it up on its own.
