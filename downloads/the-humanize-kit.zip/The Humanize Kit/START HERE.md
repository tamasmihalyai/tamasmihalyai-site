# The Humanize Kit, start here

Thanks for getting the kit. This gets you set up in a couple of minutes, whichever tool you use.

## The fastest way

Upload this whole zip to your AI tool and say: **"set up the Humanize Kit."** It reads this file, works out which tool you're in, and sets you up.

It's built and tested for **Claude Code**, where it runs best, and it also works in **Codex**, the **Claude app**, and **ChatGPT** (Team and Enterprise, where ChatGPT supports skills).

In Claude Code and Codex it installs the skills onto your computer for you. In the Claude app and ChatGPT it can't add them to your settings for you, so it loads them into your chat to use now, and shows you the one quick step to make them permanent.

## Or set it up yourself

Open the **SET UP** folder and follow the file for your tool:

- **Claude Code.md** (built and tested here, the best place to run it)
- **Codex.md** (same setup as Claude Code)
- **Claude app.md** (works fine and tested; Claude Code or Codex is smoother)
- **ChatGPT.md** (Team and Enterprise, where ChatGPT supports skills)

Each one is short and walks you through it.

## What's in the kit

- **humanize**, the skill that takes the AI out of a draft and scores it.
- **voice-fingerprint**, the skill that captures how you write, so the rewrite sounds like you.
- **The Humanize Kit - Guide.pdf**, the full setup and use guide. Read this for the walkthrough and the why behind it.
- **The Humanize Kit - Worked Examples.pdf**, three real before-and-after drafts with the scores, so you can see what good looks like.
- **background.md**, a quick note on how I built the kit, and the people I learned from.

## Once it's set up

1. Capture your voice first. A few minutes with the voice-fingerprint skill, and you only do it once.
2. Paste a draft and ask it to humanise the writing and give you the score.
3. Run it on anything before you publish it.

The guide has the full walkthrough.

Questions? Just reply to your purchase email, I read every one.

---

*For the AI assistant reading this:* the user has uploaded the Humanize Kit and probably wants it set up. Work out which environment you are (Claude Code, Codex, the Claude app, or ChatGPT) and follow `SET UP/<that tool>.md` exactly. In Claude Code and Codex you install the two skill folders to disk. In the Claude app and ChatGPT you load the skills into this chat, show the user the Get started steps, then give them the steps for permanent setup. The two folders to handle are `humanize/` and `voice-fingerprint/`. Ignore `__MACOSX/`, `.DS_Store`, and any wrapper folder named `The Humanize Kit`.
