# Background

A quick note on where this came from, because the work is the thing you're paying for.

Most of my work is agentic now, around 95% of it. These tools have got genuinely good, and more people are picking them up every month. I figured it was time to build something really good, so people can finally use them for content that sounds like a real person.

What makes it work is the two skills, built to run together. The Humanize skill finds the AI patterns and rewrites them, and a small Python script scores the draft so you can watch the AI fingerprint drop, before and after. The voice-fingerprint skill captures how you actually write into a reusable file. Each is useful on its own, but together is where it clicks: the humanizer takes the AI out, the voice fingerprint puts you back in, and the score proves it worked. Most setups only do one half of that.

There are good skills out there, like Kyle Balmer's "ai-tells" and others, and the Wikipedia "Signs of AI writing" notes are genuinely useful. I built my own version from my own experience, my previous prompt systems, and my own way of thinking, tuned for marketing, web copy, and personal brands. The kind of content that actually sounds like you.

I built it from real client work and kept rebuilding it over weeks until it held up. It keeps improving, and you get every update.
