---
name: humanize
description: Strip the AI fingerprint out of a draft so it reads like a person wrote it, then prove it with a tell-density score. Use whenever someone says "humanize this," "de-AI this," "does this sound like ChatGPT/AI," "remove the AI smell," "make this sound human," "is this AI-y," or pastes a draft and asks why it reads like a robot. Rewrites toward a specific voice when a voice fingerprint is provided, or toward plain natural prose when one isn't. Never changes what the text claims — only how it's said. Runs standalone on any draft, and also runs automatically as the final pass of the content-creation skill.
---

# Humanize

You take a draft and remove the machine fingerprint, so it reads like a real person wrote it. The default output of a language model has a recognisable texture: certain words, a balanced cadence, em dashes everywhere, contrast for its own sake, throat-clearing openers. Your job is to find that texture and replace it with plain, varied, human writing.

This is the **negative pass**: you remove the AI. You do not invent, embellish, or restrategise. If a voice fingerprint is supplied, you rewrite *toward that person's voice*. If not, you rewrite toward clean, natural prose that no longer pattern-matches as machine-made.

You run two ways: **standalone** (someone pastes a draft and asks you to humanize it) and as the **built-in final pass of `content-creation`** (it hands you copy that is already strategically correct and asks you to de-AI it).

## Two hard rules

**1. Meaning-lock. Change how it's said, never what it claims.** You may recast sentences, swap words, break up rhythm, cut filler. You may not add a fact, remove a fact, soften or strengthen a claim, touch a number, alter a CTA, change a link or its anchor, or move keywords out of place. In the content-creation pipeline the draft you receive is already true and on-strategy; your edits must keep every claim, proof point and routing decision exactly as they were. If removing a tell would change meaning, find a different phrasing or leave it.

**2. Natural frequency, not zero.** The goal is a human distribution of these patterns, not their total absence. Real people start a sentence with "But," and draw the occasional contrast. (Em dashes are the one exception: treat them as zero, not "some". They're a top tell, and a comma almost always does the job.) Strip every one of these to zero and you get prose that is clean in a different, equally robotic way. Aim for what a good human writer does, which is *some*, used well. And check context before cutting a flagged word: "robust" is a tell in "robust solution" and correct in "a robust statistical test." The catalogue flags candidates; you decide.

## The tell to hunt hardest: the contrast-flip rhythm

One tell matters more than the rest, because it's the model's default rhythm and the lint can't fully see it: the **contrast flip**, where a point is made by setting up a negative and flipping to a positive. It comes in a family of forms:

- **"X, not Y"** — *"one joined-up job, not four disconnected ones."*
- **"X instead of Y" / "X rather than Y"** — *"run by one partner instead of four."*
- **"not just X, but Y" / "it's not just X, it's Y."**
- **The two-sentence flip** — a short negative sentence then a short positive one: *"This isn't a feature I bolt on. It's how the work gets done." · "None of that is your fault. It's the setup."*

Read the whole draft once with the single job of finding these. The lint catches some, but most slip past a regex, so your own read is the real catch. The fix is almost always to **state the point as a plain positive and drop the negative half**, or to carry a genuine contrast in a table or list instead of the sentence rhythm. When a voice fingerprint bans this construction (some do, emphatically), treat it as absolute — zero, not "natural frequency."

## Inputs

- **The draft** (required) — the text to humanize.
- **`voice-fingerprint.md`** (optional) — if present, rewrite toward this voice, not toward generic-human. Match its rhythm, vocabulary, punctuation habits and signature moves. (Captured by the brand-context skill; see that skill's voice step.)
- **The brand's words-to-avoid** from `brand-context.md` (optional) — fold these brand-specific bans into the blocklist alongside the universal tells, so personal pet-hates ("AI-powered," "leverage," "synergy") get caught too.

## Workflow

### Step 1 — Run the lint script
Run `scripts/ai_tells_lint.py` on the draft for the deterministic tells (em-dash rate, Tier-1 words, negative-parallelism patterns, copula avoidance, vague attribution, throat-clearing openers, title-case headings, boldface density, sentence-length uniformity). It gives you an objective readout with line numbers and a weighted score. The script is a flashlight, not an executioner: it surfaces candidates, it doesn't decide. See [the lint script](#the-lint-script).

### Step 2 — Read for the tells the script can't catch
The script finds patterns; you find the judgment-level problems: hollow sentences that add no information, empty puffery, register that's off for the audience, a rule-of-three that reads padded, contrast used as a crutch, a paragraph that says nothing. Read the whole thing as a sceptical human. Use **[references/tells-catalogue.md](references/tells-catalogue.md)** for the full tiered catalogue and the replacement patterns.

### Step 3 — Score and rate severity
Combine the script's weighted score with what you found by reading. Rate it: **clean** (ship after light touches), **moderate** (edit), **heavy** (heavy edit), or **rewrite from intent** (so saturated that editing tell-by-tell won't save it; restate the meaning from scratch). Rough guide: under ~1 weighted tell per 100 words is clean; 3–6 is heavy; 6+ means rewrite.

### Step 4 — Rewrite
Fix each tell, honouring both hard rules. Replace Tier-1 words with the plain equivalent. Break negative-parallelism into direct statements (keep at most one contrast where it genuinely earns emphasis). Restore "is" where a marketing verb replaced it. Vary sentence length deliberately. Cut throat-clearing openers and hollow clauses. If a fingerprint is supplied, push the rewrite toward its rhythm and vocabulary, not just toward neutral. The catalogue gives a replacement for each tell.

### Step 5 — Self-audit and re-score
Re-run the lint script on your rewrite and reread it. Show the **before/after score and the delta** so the improvement is proven, not asserted. If anything still scores heavy, go again. Confirm the two hard rules held: no claim changed, nothing sterilised to an unnatural zero.

### Step 6 — Output
Return the result in the format below.

## Tiers and scoring (summary)

The full lists live in **[references/tells-catalogue.md](references/tells-catalogue.md)**. The tiers exist so you don't treat every flagged item the same — a flat blocklist produces stilted copy and false positives.

- **Tier 1 — zero-tolerance words.** Almost never right in real writing: *delve, tapestry, testament, multifaceted, realm, underscore (verb), showcase (verb), boasts (=has), nestled, myriad, plethora, seamless, unlock/elevate/embark (figurative).* Replace on sight (after the context check).
- **Tier 2 — judge in context.** Often fine, often a tell: *crucial, essential, vital, key, enhance, valuable, robust, foster, navigate, harness, streamline, empower.* Keep if it carries real meaning; cut if it's filler.
- **Tier 3 — puffery.** Allowed only if specific and evidenced: *commitment to, stands as a testament, rich tapestry, in the heart of, renowned for, world-class, best-in-class, game-changing.* For a proof-led brand, an unearned superlative is a tell; a specific, backed claim is not.
- **Structural tells** (weighted heavily): negative parallelism ("it's not just X, it's Y"), adjective triads, copula avoidance ("serves as / marks / represents" for "is"), present-participle summary tails ("…, highlighting its role"), vague attribution, hedge stacking, the "Despite challenges, X continues" closer.
- **Punctuation and formatting:** em dashes (zero-tolerance: use a comma), boldface overuse, bold-term-colon list rows, title-case headings, uniform sentence length.

## The lint script

```bash
python3 ~/.claude/skills/humanize/scripts/ai_tells_lint.py <path-to-draft>
# or pipe text:
cat draft.md | python3 ~/.claude/skills/humanize/scripts/ai_tells_lint.py -
```

It prints per-category hits with line numbers, a weighted tells score, a rate per 1,000 words, and a severity band. No dependencies beyond Python 3. Run it in Step 1 and again in Step 5 to show the delta.

## Output format

```markdown
## Humanize report

**Before:** [weighted score] · [tells/1k words] · severity: [band]
**After:**  [weighted score] · [tells/1k words] · severity: [band]   ← the delta is the proof

### What I changed (by category)
- [tell] → [fix], ×N   (e.g. em dashes 41 → 0; "it's not X it's Y" ×6 → 1; "delve/showcase/underscore" removed)

### Flags
- [anything I left on purpose and why — e.g. one em dash kept for natural rhythm]
- [any tell I could not fix without changing meaning — surfaced, not silently cut]

---
[the humanized text]
```

When called inside content-creation, fold this into that skill's build notes rather than printing a separate report.

## When to restart instead of edit

If the draft scores in the **rewrite-from-intent** band, don't polish it tell-by-tell. Pull out what it's actually trying to say (the claims, the structure, the proof) and write it again plainly. Editing heavily-saturated AI text often leaves a faint machine residue; restating from meaning removes it. Meaning-lock still applies: same claims, new prose.

## As a pipeline step vs standalone

- **Standalone:** the draft is whatever was pasted. Humanize toward the fingerprint if one is named, else toward plain prose. Print the full report.
- **Inside content-creation:** the draft is already true and on-strategy. Be especially strict with meaning-lock (the strategy was hard-won upstream), use the project's `voice-fingerprint.md`, and report inside the page's build notes.

## Credits

The general approach (tiered word lists, a tell-density score, a self-audit pass) is common to many de-AI tools; this build was informed by Kyle Balmer's `ai-tells` skill (MIT) and the Wikipedia essay "Signs of AI writing" (CC BY-SA). Catalogue and code here are original and filtered for marketing/web copy. The fuller story is in `background.md` at the root of the kit.
