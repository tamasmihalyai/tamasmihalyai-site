# The AI-tells catalogue (marketing-filtered)

The working catalogue of AI writing tells, tiered so you don't treat them all the same, and filtered for marketing and web copy. Each entry says what the tell is and what to do instead. This is original, written for this system; it draws on the factual tells documented in the Wikipedia essay "Signs of AI writing" (CC BY-SA) and the tiered approach in Kyle Balmer's `ai-tells` (MIT), filtered down to what matters for landing pages, service pages, blogs and emails.

**Contents**
- [How to use the tiers](#how-to-use-the-tiers)
- [Tier 1 — zero-tolerance words](#tier-1--zero-tolerance-words)
- [Tier 2 — judge in context](#tier-2--judge-in-context)
- [Tier 3 — puffery and empty superlatives](#tier-3--puffery-and-empty-superlatives)
- [Structural tells](#structural-tells)
- [Throat-clearing and tone tells](#throat-clearing-and-tone-tells)
- [Punctuation and formatting tells](#punctuation-and-formatting-tells)
- [Before / after](#before--after)
- [What we deliberately left out](#what-we-deliberately-left-out)

---

## How to use the tiers

The point of tiering is to avoid two failure modes: a flat blocklist that nukes legitimate words (false positives, stilted copy), and a vibes-only pass that misses the obvious. So:

- **Tier 1:** replace on sight, after a one-second context check.
- **Tier 2:** keep if the word carries real meaning in that sentence; cut if it's filler.
- **Tier 3:** allow only if the claim is specific and evidenced. For a proof-led brand, an unearned superlative is a tell.
- **Structural / punctuation / formatting:** the highest-value catches, because they're what makes text *feel* machine-made even when no single word is wrong.

And always: **natural frequency, not zero.** One em dash on a page is human. One contrast for real emphasis is human. The goal is a human distribution, not sterilisation.

---

## Tier 1 — zero-tolerance words

Almost never the right word in real writing. When they appear, they're nearly always the model reaching for its default register. Replace with the plain equivalent.

| Tell | Use instead |
|---|---|
| delve (into) | look at, dig into, get into |
| tapestry / rich tapestry | (cut; name the actual thing) |
| testament (to) / stands as a testament | shows, proves (or cut) |
| multifaceted | has several sides (or cut) |
| realm (figurative) | area, field, world |
| underscore (verb) | shows, stresses, points to |
| showcase (verb) | show, present |
| boasts (= has) | has, comes with |
| nestled (in/within) | in, sits in |
| myriad / plethora | many, lots of, a range of |
| seamless / seamlessly | smooth, with no handovers (be concrete) |
| unlock / elevate / embark (figurative) | (cut; say the literal thing) |
| harness (figurative) | use, put to work |
| foster (abstract) | build, support, encourage |
| navigate (figurative) | deal with, handle, work through |
| intricate / intricacies | detailed, the details |
| vibrant (filler) | (cut or name the specific quality) |
| ever-evolving / ever-changing | changing (or be specific about how) |

The figurative test for words like *unlock, elevate, harness, navigate, embark:* if no one is literally opening a lock or steering a ship, it's the tell. Cut it.

## Tier 2 — judge in context

Frequently fine, frequently filler. Keep when the word does real work; cut when it's padding.

`crucial, essential, vital, key, critical, significant, valuable, robust, powerful, comprehensive, innovative, streamline, empower, enhance, optimise, facilitate, utilise, leverage, drive, enable`

- Quick test: delete the word. If the sentence means the same, it was filler. "A key part of marketing" usually survives as "part of marketing."
- `utilise` → `use`. `leverage` → `use` (and it's on the brand avoid-list anyway). `facilitate` → `help`, `run`.
- "comprehensive / robust / powerful" attached to your own offer is usually unearned puffery (see Tier 3). "a robust test," "a powerful argument with evidence behind it" can be real.

## Tier 3 — puffery and empty superlatives

Allowed only when the claim is specific and backed. This is where marketing differs from an encyclopedia: marketing is allowed to be positive, but a proof-led brand earns it. Unearned, it's a tell.

`commitment to (excellence/quality), world-class, best-in-class, cutting-edge, game-changing, revolutionary, transformative, industry-leading, state-of-the-art, renowned for, trusted by [vague], passionate about, in the heart of, take it to the next level, gold standard`

- The test: is there a number, a named example, or a verifiable fact behind it? "Trusted by 200 clinics" is fine. "Trusted by businesses everywhere" is a tell.
- Several of these (revolutionary, transformative, cutting-edge) are also on the Thriving Colibri avoid-list. When a brand's words-to-avoid are supplied, fold them in here.

## Structural tells

The high-value catches. These make writing feel machine-made even when the vocabulary is clean.

- **The contrast-flip rhythm (the worst offender — a whole family).** A point made by setting up a negative and flipping to a positive. The model's default rhythm, so it saturates drafts. Ban the family:
  - "X, not Y" — *"one joined-up job, not four disconnected ones."*
  - "X instead of Y" / "X rather than Y" — *"run by one partner instead of four."*
  - "not just X, but Y" / "it's not just X, it's Y."
  - The two-sentence flip — short negative then short positive: *"This isn't a feature I bolt on. It's how the work gets done." · "You don't need a lecture. You need to know..."*
  **Fix:** state it as a plain positive and stop, or carry a real contrast in a table/list, not in the sentence rhythm. Keep at most one genuine contrast per page; default to zero. The regex catches only some forms, so this must be hunted by reading.
- **Adjective triads / rule of three.** "fast, affordable, and reliable." "strategy, execution, and growth." Three balanced items create false comprehensiveness. Vary it: use two, or four, or one strong specific.
- **Copula avoidance.** Replacing "is/are" with a marketing verb: "serves as," "stands as," "marks," "represents," "features," "acts as." Put plain "is" back unless the verb is literally true.
- **Present-participle summary tails.** Clauses bolted on the end to sound analytical: "…, highlighting its role in growth." "…, reflecting a broader shift." "…, underscoring the importance of X." Cut them or make them a real sentence with a real point.
- **Vague attribution.** "Studies show," "experts say," "research suggests," "it's widely known," "many businesses find." Name the source or drop the claim.
- **Hedge stacking.** "may potentially help," "could possibly improve." Pick one level of certainty.
- **The concession closer.** "Despite the challenges, X continues to thrive." "While there's work to do, the future looks bright." Generic, content-free endings. End on something specific instead.
- **Hollow sentences.** A sentence that, removed, costs the reader nothing. Common after a heading ("When it comes to pricing, pricing matters."). Delete or replace with the actual point.

## Throat-clearing and tone tells

- **Opener throat-clearing:** "In today's fast-paced world," "In an era of," "In the world of," "In the realm of," "When it comes to," "Now more than ever." Cut entirely; open with the point or the reader's situation.
- **Connective stacking:** sentence-initial "Moreover," "Furthermore," "Additionally," "Interestingly," "Notably." Use rarely; let logic connect the ideas.
- **"It's important to note that," "It's worth mentioning," "Needless to say."** Delete; say the thing.
- **Chatbot residue:** "Great question!", "Certainly!", "I'd be happy to help," "In conclusion," "I hope this helps." Remove.
- **Knowledge-cutoff / hedging disclaimers** that don't belong in published copy.

## Punctuation and formatting tells

- **Em-dash overuse.** The signature punctuation tell. Target a natural rate (roughly no more than 2–3 per 500 words, and not as the default joiner). Replace most with a full stop, a comma, or a restructured sentence. Keep the occasional one.
- **Boldface overuse.** More than ~2 bolded runs per section, or bolding for emphasis mid-sentence repeatedly, reads as machine formatting. Bold sparingly.
- **Bold-term-colon list rows.** "**Speed:** fast. **Breadth:** wide." A whole list built this way is a tell. Vary the structure, or write "**Term.** Sentence." or prose.
- **Title-case headings** in a sentence-case context: "How We Help Your Business Grow." Use sentence case: "How we help your business grow."
- **Uniform sentence length.** Strings of similar-length sentences read flat and robotic. Vary deliberately: a longer sentence that builds, then a short one.

## Before / after

**1. Negative parallelism + Tier 1 word**
- Before: "This isn't just marketing — it's a seamless journey that delves into what your customers truly want."
- After: "It's marketing that starts from what your customers actually want."

**2. Copula avoidance + puffery**
- Before: "Our platform serves as a world-class solution that stands as a testament to innovation."
- After: "The platform does one thing well: [specific thing]." (then prove it)

**3. Throat-clearing + triad + em dashes**
- Before: "In today's fast-paced digital world, businesses need speed, agility, and innovation — partners who get it — to thrive."
- After: "Most businesses just need marketing that moves quickly and actually works."

**4. Present-participle tail + vague attribution**
- Before: "Studies show content drives growth, highlighting its pivotal role in the modern marketing landscape."
- After: "Good content brings in customers. Here's what that looked like for [named example]."

Notice each "after" is shorter, plainer, and makes a concrete claim. That's the direction of every fix.

## What we deliberately left out

The Wikipedia essay catalogues many tells specific to **encyclopedia** writing that don't apply to marketing copy, and we left them out on purpose: conservation/ecology-status padding, "maintains an active social media presence," lists of media outlets a subject was covered in, heritage/architecture description puffery, and citation-formatting artefacts. Pulling those in would add noise without helping a landing page. If this skill is ever pointed at encyclopedic or reference content, revisit them.

## Project-specific tell: the AI / human "see-saw" (added 6 Jun 2026)

The balanced two-clause statement of an AI-vs-human split. The *message* ("AI does the fast/grunt work, the judgement is human") is often legitimate brand positioning, but expressing it as a tidy symmetrical flip is a strong AI tell — and it tends to repeat across pages like a stock phrase.

Forms to flag:
- "AI for the speed, me for the judgement" — the "X for the A, Y for the B" template.
- "AI does the crunching, I read what it's telling you" — comma-spliced "A does X, I do Y".
- "AI does the legwork; the strategy is human" — the same flip with a semicolon.

Two REVIEW-tier patterns for these are in `ai_tells_lint.py`. Fix: keep the meaning, drop the symmetry — one plain sentence, two real sentences, or a loosened clause/list — and vary it so no two pages use the same template.

Related punctuation note: prefer full stops over semicolons. The model over-reaches for semicolons and grammatically over-correct punctuation, which reads formal; use one only when it genuinely links two tightly-bound clauses.
