#!/usr/bin/env python3
"""
ai_tells_lint.py — a deterministic flashlight for AI writing tells.

It REPORTS candidates; it does not decide. The model reads the report,
applies judgment (context, voice, false positives), and rewrites.

Usage:
    python3 ai_tells_lint.py <path-to-file>
    cat draft.md | python3 ai_tells_lint.py -

Scope note: tuned for marketing / web / blog copy. It scans prose, and by
default skips fenced code blocks. It is a heuristic: a high score means
"look here," not "this is bad." Natural frequency, not zero, is the goal.
"""

import sys
import re

# ---- tell definitions -------------------------------------------------------

# Tier 1: near-always a tell in real writing. Weight 3 each.
TIER1 = [
    "delve", "delves", "delving", "tapestry", "testament", "multifaceted",
    "underscore", "underscores", "underscoring", "showcase", "showcases",
    "showcasing", "nestled", "myriad", "plethora", "seamless", "seamlessly",
    "realm", "realms", "intricate", "intricacies", "ever-evolving",
    "ever-changing", "boasts", "harness", "harnessing", "unlock", "unlocks",
    "unlocking", "elevate", "elevates", "elevating", "embark",
]

# Tier 2: context-dependent. Weight 1 each (filler-or-not is the model's call).
TIER2 = [
    "crucial", "essential", "vital", "robust", "comprehensive", "innovative",
    "streamline", "streamlines", "empower", "empowers", "enhance", "enhances",
    "facilitate", "facilitates", "utilise", "utilize", "leverage", "leverages",
    "pivotal", "foster", "fosters", "navigate", "navigating",
]

# Tier 3 / puffery: allowed only if specific + evidenced. Weight 2 each.
PUFFERY = [
    "world-class", "best-in-class", "cutting-edge", "game-changing",
    "revolutionary", "transformative", "industry-leading", "state-of-the-art",
    "commitment to excellence", "renowned for", "passionate about",
    "in the heart of", "next level", "gold standard", "unparalleled",
]

# Structural regexes. (pattern, label, weight)
STRUCTURAL = [
    (r"\b(?:it'?s|that'?s|this is)\s+not\s+(?:just|only|merely|about)\b.*?\b(?:it'?s|but)\b",
     "negative parallelism (it's not just X, it's Y)", 3),
    (r"\bnot\s+(?:just|only|merely)\b[^.?!]*?\bbut\b",
     "negative parallelism (not only X but Y)", 3),
    (r"\bisn'?t\s+(?:just|only|about)\b",
     "negative parallelism (isn't just X)", 2),
    (r"\b(?:isn'?t|aren'?t|wasn'?t|weren'?t|don'?t|doesn'?t|didn'?t|won'?t)\b[^.!?]{2,70}[.!?]\s+(?:It'?s|That'?s|It|They|You|I|We|He|She)\b[^.!?]{0,60}[.!?]",
     "REVIEW: two-sentence contrast flip (X isn't A. It's B.) — confirm; common AI tell", 2),
    (r",\s+not\s+(?:just\s+|only\s+|merely\s+)?\w+",
     "REVIEW: 'X, not Y' comma-contrast — confirm (top AI/Tamas tell)", 2),
    (r"\binstead of\b",
     "REVIEW: 'X instead of Y' contrast — confirm (banned antithesis family)", 2),
    (r"\brather than\b",
     "REVIEW: 'X rather than Y' contrast — confirm (banned antithesis family)", 2),
    (r"\bAI\s+for\s+(?:the\s+)?\w+,\s+(?:me|I|my|a)\b",
     "REVIEW: 'AI for X, me for Y' balanced see-saw — vary per page (AI/Tamas tell)", 2),
    (r"\bAI\s+(?:does|handles|crunches|makes|runs|takes care of)\b[^,.!?]{2,45},\s+(?:I|me|a\s+(?:human|person|marketer|real))\b",
     "REVIEW: 'AI does X, I do Y' comma-splice split — vary/rephrase (AI/Tamas tell)", 2),
    (r"\b(?:serves|serving|stands|standing|acts|acting)\s+as\b",
     "copula avoidance (serves/stands as -> is)", 1),
    (r"\b(?:marks|represents|reflects|embodies|signifies)\s+(?:a|an|the)\b",
     "copula avoidance (marks/represents a)", 1),
    (r",\s+\w+ing\b[^.?!]*?(?:role|importance|shift|move|significance|landscape)\b",
     "present-participle summary tail (..., highlighting its role)", 2),
    (r"\b(?:studies show|experts say|research suggests|it is widely|it'?s widely|many believe|some argue|observers (?:note|say)|industry reports)\b",
     "vague attribution", 2),
    (r"\b(?:may|might|could)\s+(?:potentially|possibly)\b",
     "hedge stacking", 1),
    (r"\b[Dd]espite\b[^.?!]*?,\s*[^.?!]*?\b(?:continues|remains|thrives|still)\b",
     "concession closer (Despite X, Y continues)", 2),
]

# Throat-clearing openers. Weight 3 each.
OPENERS = [
    r"\bin today'?s\b", r"\bin an era\b", r"\bin the world of\b",
    r"\bin the realm of\b", r"\bnow more than ever\b",
    r"\bin a world (?:where|of)\b", r"\bwhen it comes to\b",
]

# Tone / chatbot residue. Weight 2 each.
TONE = [
    r"\bit'?s important to note\b", r"\bit'?s worth (?:noting|mentioning)\b",
    r"\bneedless to say\b", r"\bgreat question\b", r"\bi'?d be happy to\b",
    r"\bin conclusion\b", r"\bi hope this helps\b",
    r"(?m)^\s*(?:moreover|furthermore|additionally|notably|interestingly)\b",
]

# ---- helpers ----------------------------------------------------------------

def strip_code_blocks(text):
    return re.sub(r"```.*?```", "", text, flags=re.DOTALL)

def line_of(text, idx):
    return text.count("\n", 0, idx) + 1

def find_words(text, words):
    hits = []
    for w in words:
        for m in re.finditer(r"\b" + re.escape(w) + r"\b", text, re.IGNORECASE):
            hits.append((line_of(text, m.start()), m.group(0)))
    return hits

def find_patterns(text, patterns):
    """patterns: list of (regex, label, weight). Returns label -> [(line, snippet)]."""
    out = {}
    for pat, label, weight in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            out.setdefault((label, weight), []).append(
                (line_of(text, m.start()), re.sub(r"\s+", " ", m.group(0))[:70])
            )
    return out

def find_regex_list(text, regexes):
    hits = []
    for pat in regexes:
        for m in re.finditer(pat, text, re.IGNORECASE):
            hits.append((line_of(text, m.start()), re.sub(r"\s+", " ", m.group(0))[:50]))
    return hits

def sentences(text):
    flat = re.sub(r"\s+", " ", re.sub(r"[#>*_`\-\|]", " ", text))
    parts = re.split(r"(?<=[.!?])\s+", flat)
    return [p for p in parts if len(p.split()) >= 3]

# ---- main -------------------------------------------------------------------

def analyse(raw):
    text = strip_code_blocks(raw)
    words = re.findall(r"\b\w+\b", text)
    wc = max(len(words), 1)

    report = []
    score = 0.0

    def section(title, items, weight_each, examples=True):
        nonlocal score
        if not items:
            return
        pts = weight_each * len(items)
        score += pts
        report.append(f"\n[{title}]  hits: {len(items)}  (+{pts:g} pts)")
        if examples:
            shown = items[:8]
            for ln, snip in shown:
                report.append(f"    line {ln}: {snip}")
            if len(items) > 8:
                report.append(f"    ... and {len(items) - 8} more")

    # Word tiers
    section("Tier 1 words (zero-tolerance)", find_words(text, TIER1), 3)
    section("Tier 2 words (judge in context)", find_words(text, TIER2), 1)
    section("Tier 3 puffery (allow only if evidenced)", find_words(text, PUFFERY), 2)

    # Structural
    struct = find_patterns(text, STRUCTURAL)
    for (label, weight), items in sorted(struct.items(), key=lambda x: -len(x[1])):
        section(label, items, weight)

    # Openers + tone
    section("Throat-clearing openers", find_regex_list(text, OPENERS), 3)
    section("Tone / chatbot residue", find_regex_list(text, TONE), 2)

    # Em dashes: zero-tolerance. One of the loudest AI tells; a single em dash makes
    # readers think "AI". Replace with a comma (or a full stop), even where an em dash
    # would be more grammatically correct. Weighted 2 each, every one flagged.
    em = [(line_of(text, m.start()), "—") for m in re.finditer("—", text)]
    section("Em dashes (zero-tolerance: use a comma)", em, 2)

    # Boldface density (markdown **bold**)
    bold = len(re.findall(r"\*\*[^*\n]+\*\*", text))
    bold_rate = bold / wc * 100
    if bold_rate > 2.0:
        pts = round(bold_rate - 2.0, 1)
        score += pts
        report.append(f"\n[Boldface density]  {bold} bold runs  rate: {bold_rate:.1f}/100 words  [OVER ~2]  (+{pts:g} pts)")

    # Title-case headings
    tc = []
    for m in re.finditer(r"(?m)^#{1,6}\s+(.+)$", raw):
        h = m.group(1).strip()
        ws = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]*", h)]
        caps = [w for w in ws if w[0].isupper()]
        small = {"a","an","the","and","or","but","for","of","to","in","on","with","vs"}
        if len(ws) >= 3 and len(caps) >= sum(1 for w in ws if w.lower() not in small):
            tc.append((line_of(raw, m.start()), h[:60]))
    section("Title-case headings (use sentence case)", tc, 2)

    # Sentence-length uniformity
    sents = sentences(text)
    note = ""
    if len(sents) >= 8:
        lens = [len(s.split()) for s in sents]
        mean = sum(lens) / len(lens)
        var = sum((x - mean) ** 2 for x in lens) / len(lens)
        sd = var ** 0.5
        cov = sd / mean if mean else 0
        note = f"\n[Sentence rhythm]  {len(sents)} sentences  mean {mean:.0f} words  stdev {sd:.1f}  variation {cov:.2f}"
        if cov < 0.45:
            score += 2
            note += "  [LOW variation — reads uniform/robotic]  (+2 pts)"
        else:
            note += "  [OK]"
        report.append(note)

    # Score band
    rate = score / wc * 1000
    if rate < 4:
        band = "CLEAN-ish (light touches)"
    elif rate < 12:
        band = "MODERATE (edit)"
    elif rate < 25:
        band = "HEAVY (heavy edit)"
    else:
        band = "REWRITE FROM INTENT (too saturated to polish)"

    header = [
        "=" * 64,
        "AI-TELLS LINT REPORT",
        "=" * 64,
        f"Word count: {wc}",
        f"Weighted tells score: {score:.1f}",
        f"Rate: {rate:.1f} weighted tells / 1,000 words",
        f"Severity: {band}",
        "-" * 64,
        "(Flashlight, not executioner: confirm each hit in context before cutting.",
        " Goal is natural frequency, not zero.)",
    ]
    if not report:
        report.append("\nNo flagged patterns. Still read it like a human.")
    return "\n".join(header + report) + "\n"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    arg = sys.argv[1]
    if arg == "-":
        raw = sys.stdin.read()
    else:
        with open(arg, "r", encoding="utf-8") as f:
            raw = f.read()
    print(analyse(raw))


if __name__ == "__main__":
    main()
