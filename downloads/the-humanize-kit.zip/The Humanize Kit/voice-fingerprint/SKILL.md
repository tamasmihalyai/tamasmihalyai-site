---
name: voice-fingerprint
description: Capture how a specific person or brand actually writes into a reusable Voice Fingerprint file (`.agents/voice-fingerprint.md`) that the content-creation and humanize skills read, so AI writing sounds like THEM and not like AI. Use when the user says "capture my voice," "capture my client's voice," "voice fingerprint," "make it sound like me/them," "tone of voice guide," "brand voice," "define how we write," "voice/style guide," or points at transcripts, posts, or copy and asks to pin down how someone writes. Built on AI-free samples and a real testing loop, not a one-off "capture my tone" prompt. Runs standalone, or as the voice step of brand-context.
---

# Voice Fingerprint

You capture how a specific person (or brand) actually writes, and save it to a reusable file, `.agents/voice-fingerprint.md`, that every writing skill reads first. This is the missing input that makes AI content sound like a real, specific person instead of de-AI'd generic prose.

`content-creation` reads it to write in the voice. `humanize` reads it to rewrite toward it. It's a pluggable data file: swap the file, swap the voice. That's what makes the whole system work for any client, not just one brand.

## Why this beats "just prompt it to capture my tone"

A one-off "capture my tone and write like this" prompt gets someone partway, for one chat. This is the difference between that and a voice that holds up everywhere, every time. Keep this framing; it's also the honest sales angle for any product built on this skill.

- **It's a saved file, reused everywhere.** A prompt dies with the chat. The fingerprint is a file you hand to any tool, on any piece, forever.
- **It trusts only AI-free samples.** The most common mistake is capturing from AI-assisted writing, which carries the AI's fingerprint, not the person's. The rule in Step 2 fixes that, and almost nobody knows to do it.
- **It's built through a testing loop, not one shot:** capture, test on a real piece, catch what's still off, fix, re-test.
- **It anchors on the person's real sentences and bans drift.** A description slides back to "fluent writer." Real lines plus the anti-drift rules in Step 5 stop that.

## The one rule above all: write like they talk

The biggest mistake is capturing a voice that's better than how the person actually talks. Don't. The goal is no gap between how they sound out loud and how they read on the page. Match their real speech, lightly tidied, never polished up into "good writing."

## Workflow

### 1. Get samples (priority ladder)
Voice can't be invented from a description, it has to be observed. Ask for the best source they have, and stop as soon as you have one or two good ones:
1. An existing tone-of-voice / brand guide (fastest start if a real one exists).
2. Real published copy they're happy with.
3. Long-form they wrote (posts, articles, newsletters).
4. Short-form (captions).
5. If none: ask them to *talk* (record and transcribe, people are far more themselves out loud), or draft 2–3 candidate voices for one paragraph, let them pick, then refine.

### 2. Trust only AI-free samples for style (the rule that decides if it's real)
A sample the AI drafted, tidied, or "polished" carries the AI's fingerprint, not the person's, and people routinely mistake that polish for their own voice. So:
- Ask of every sample: "Did a human write this start to finish, or did AI touch it?"
- **AI-free** (voice notes, transcripts, pre-AI writing, things typed straight out): trust for **style**, the rhythm, word choice, signature moves.
- **AI-assisted:** use for **substance only**, the topics, values, claims, never the sentence style. Record which sources were which.

### 3. Translate spoken → written (when the source is voice or video)
Transcripts are the cleanest voice source you'll get, but spoken language carries markers that look wrong on a page: direct-to-camera filler ("hey guys"), platform hype ("insane"), spoken connectives ("So…"), interjections ("boom"). Keep the durable personality (directness, momentum, warmth, concreteness) and drop the platform surface. The template has a register-translation table.

### 4. Distil into the fixed 6-part schema
Use [references/voice-fingerprint-template.md](references/voice-fingerprint-template.md). The six parts: (1) samples, (2) style attributes (POV, formality, rhythm, vocabulary, punctuation, devices), (3) signature moves, (4) words to use / avoid (pet-hates live here), (5) a before/after example, (6) what the voice is NOT.

### 5. The anti-drift rules (this is what the testing taught, and what makes it actually sound like them)
- **Anchor on real lines.** Pin 4–6 of the person's actual sentences into the file as the gold standard to match. A description drifts; a real sentence is something to copy. This is the single biggest lever.
- **Ban writerly phrasing, not just fancy words.** A line can use only simple words and still be writerly: a little image, a metaphor, a crafted "literary" beat. Cut it. The test: would this person, explaining it simply out loud, actually say it this way?
- **Em dashes, basically never.** They're one of the loudest AI tells. Use a comma instead. Keep them only if a clean sample proves the person genuinely uses them.
- **The contrast / antithesis family, banned:** "X, not Y", "X instead of Y / rather than", "not just X, but Y" / "it's not X, it's Y", and the two-sentence flip (short negative then short positive). It's the model's default rhythm and most people hear it instantly as AI. Fix: state the point as a plain positive and stop. Keep a form only if a clean sample proves the voice uses it.

### 6. Test it on a real piece, then loop (the magic step, most people skip it)
Don't save the first draft of the fingerprint. Hand it to `humanize` or `content-creation` on a real piece the person needs, then:
- **Read it aloud as them.** You hear instantly whether it's them.
- When something's off, work out *why* (usually a description where a real line should be, or writerly phrasing), fix the fingerprint, and run it again.
- A few rounds is normal. Each round gets closer. The loop is what turns "close" into "that's actually me".

### 7. Two checks before you call it done
- **Voice check (the real one):** read it aloud against the samples. Does it sound like them?
- **AI check:** run the `humanize` lint for the tell score. The lint measures AI-ness, not them-ness, so a clean score does NOT mean it sounds like the person. You need both.

### 8. Confirm and save
Show a generic→voice before/after: "Does this sound like you? What would you say differently?" Voice is the one thing only they can confirm. Iterate until yes, then write `.agents/voice-fingerprint.md`, noting the sources and which were AI-free. One brand or client per file.

## After this skill
The file is the team handoff. `content-creation` writes in the voice, `humanize` rewrites toward it, and both read `.agents/voice-fingerprint.md` automatically. When run as the voice step of `brand-context`, it slots in after the brand-context file is built.
