# Voice Fingerprint — [Brand / Client Name]

*[One line: whose voice this is and what it's for, e.g. "First-person founder voice for [Brand] website copy and [Name]'s own content."] For client work, each client gets their own fingerprint in this same shape: swap this file, swap the voice.*

Read by **content-creation** (write in this voice) and **humanize** (rewrite toward it). It governs *how it sounds*, not the brief's strategy.

**Sources:** [list each sample source AND whether it's AI-free or AI-assisted. AI-free = unedited speech/writing by the person, the primary source for how they sound. AI-assisted = dictated-then-tidied, drafted-with-AI, or polished by a tool, use only for substance/values/topics, never for sentence style, because the style is the AI's fingerprint, not theirs.]

---

## 1. Samples (the gold standard — match THESE, not just the description below)

A few short, verbatim excerpts from the **AI-free** sources. Pin 4–6 real lines here. These are the single most important part of the file: a description of a voice drifts, but a real sentence the person actually said or wrote is something to copy. When a draft sounds off, the first fix is to match these lines more closely.

- "[real line 1]"
- "[real line 2]"
- "[real line 3]"
- "[real line 4]"

> If the only samples are AI-assisted, say so plainly and treat every style note below as provisional until a clean sample exists.

## 2. Style attributes

How the voice is built, from the clean samples. One line each.

- **Point of view / address:** [who they talk to, e.g. straight to "you", one person]
- **Formality:** [casual ↔ formal; contractions; slang]
- **Rhythm & sentence length:** [short and punchy / long and flowing / varied; fragments? run-ons? how much variation?]
- **Energy:** [calm, energetic, dry, warm, and where the energy comes from: the substance, or adjectives?]
- **Vocabulary:** [plain vs technical; concrete vs abstract; jargon level. Note if they keep it deliberately simple.]
- **Punctuation habits:** [exclamation marks? ellipses? sentence-case headings? **Em dashes: default to NO. They're one of the loudest AI tells; use a comma. Keep them only if a clean sample proves this person genuinely uses them.**]
- **Spelling/locale:** [British vs American, e.g. optimise, judgement, programme]
- **Proof style:** [how they make a point land, real numbers, named examples, stories?]

## 3. Signature moves

The distinctive, repeatable things this voice does, the moves you'd copy to sound like them.

- **[Move 1]** — [what it is + a real example].
- **[Move 2]** — [...]
- **CTA style:** [how they ask for the action, pushy/soft, single-action, casual/formal].

## 4. Words to use / avoid

- **Words to use:** [brand words from brand-context.md + words that recur naturally in clean samples]
- **Words to avoid:** [generic AI/marketing puffery + this person's specific pet-hates, with their exact reactions]

### ⛔ Two rules that decide whether it sounds human

**Rule 1 — ban the contrast / antithesis family (hunt this hardest, every pass).** The model's default rhythm, so it creeps into every draft, and most people hear it instantly as "AI". Unless a clean sample proves this voice uses it, treat the whole family as banned:
- **"X, not Y"** — *"one joined-up job, not four disconnected ones."*
- **"X instead of Y" / "X rather than Y."**
- **"not just X, but Y" / "it's not just X, it's Y."**
- **The two-sentence flip** (short negative, then short positive): *"This isn't a feature I bolt on. It's how the work gets done."*

Fix: state the point as a plain positive and stop. If a contrast genuinely matters, carry it in a table or list, never in the sentence rhythm.

**Rule 2 — no writerly phrasing, even with plain words.** A line can use only simple words and still read like a writer wrote it: a little image, a metaphor, a crafted "literary" beat. That's still not the person. The test: *would they, explaining it simply out loud, actually say it this way?* If it reads like a line from an essay, cut it and say the plain thing.

## 5. Before / after

One worked example: generic AI prose → this voice.

- **Generic:** "[a flat, on-topic sentence in default-AI voice]"
- **[Name]:** "[the same point in this voice]"

[One line naming what changed, e.g. "Direct address. Real specifics. No hype, no em dash, no antithesis, no writerly phrasing."]

## 6. What the voice is NOT

The negative space. Saying what it isn't stops the writer drifting back to default. Be specific.

- Not [e.g. corporate / a faceless brand].
- Not [hype-driven, list the specific hype words this voice never uses].
- Not writerly or literary, no images or metaphors the person wouldn't say out loud.
- Never [the antithesis family, restated in one line so it's impossible to miss]. No em dashes.

---

## Register translation (include ONLY when sources are spoken: video / voice notes / transcripts)

Spoken sources are gold for personality but carry markers that must NOT be copied literally onto a page. Keep the personality underneath, drop the platform surface.

| Spoken (source) | Why it doesn't port to writing | In brand writing instead |
|---|---|---|
| ["guys", "hey guys"] | spoken filler / direct-to-camera | drop, or "you" |
| [hype: "insane", "mind-blowing"] | hype, often on the avoid-list | convey impact with a specific (time saved, real result) |
| ["So…" starting every sentence] | spoken connective | trim (keep the occasional one if it's genuinely them) |
| ["Boom", "Whoa"] | spoken interjections | a short punchy sentence carries the same beat |

The test: keep their **directness, momentum, practicality, warmth, concreteness**. Lose the **platform filler and hype words**.

## Register flex (optional, same voice, different dial)

- **Short-form** (social, hero copy, CTAs): [how the voice tightens]
- **Long-form** (pillar/service pages, articles): [the same voice sustained, what it must not drift into]
- **Client-facing / published** (emails, website, proposals): [a notch more polished, still plain and still them, never corporate]
